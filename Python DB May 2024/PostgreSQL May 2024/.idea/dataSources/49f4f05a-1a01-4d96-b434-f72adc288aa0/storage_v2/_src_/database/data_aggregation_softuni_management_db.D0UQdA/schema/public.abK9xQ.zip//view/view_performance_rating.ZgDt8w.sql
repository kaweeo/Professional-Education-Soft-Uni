create view view_performance_rating (first_name, last_name, job_title, salary, department_id, performance_rating) as
SELECT employees.first_name,
       employees.last_name,
       employees.job_title,
       employees.salary,
       employees.department_id,
       CASE
           WHEN employees.salary >= 25000::numeric THEN
               CASE
                   WHEN employees.job_title::text ~~ 'Senior%'::text THEN 'High-performing Senior'::text
                   ELSE 'High-performing Employee'::text
                   END
           ELSE 'Average-performing'::text
           END AS performance_rating
FROM employees;

alter table view_performance_rating
    owner to postgres;

