create function log_deleted_employee() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO deleted_employees (employee_id, first_name, last_name, middle_name, job_title, department_id,
                                       salary)
        VALUES (OLD.employee_id, OLD.first_name, OLD.last_name, OLD.middle_name, OLD.job_title, OLD.department_id,
                OLD.salary);
        RETURN OLD;
    end;
$$;

alter function log_deleted_employee() owner to postgres;

