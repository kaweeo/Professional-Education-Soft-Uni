create view view_wizard_deposits_with_expiration_date_before_1983_08_17(wizard_name, start_date, expiration_date, amount) as
SELECT concat_ws(' '::text, wizard_deposits.first_name, wizard_deposits.last_name) AS wizard_name,
       wizard_deposits.deposit_start_date                                          AS start_date,
       wizard_deposits.deposit_expiration_date                                     AS expiration_date,
       wizard_deposits.deposit_amount                                              AS amount
FROM wizard_deposits
WHERE wizard_deposits.deposit_expiration_date <= '1983-08-17'::date
GROUP BY (concat_ws(' '::text, wizard_deposits.first_name, wizard_deposits.last_name)),
         wizard_deposits.deposit_start_date, wizard_deposits.deposit_expiration_date, wizard_deposits.deposit_amount
ORDER BY wizard_deposits.deposit_expiration_date;

alter table view_wizard_deposits_with_expiration_date_before_1983_08_17
    owner to postgres;

