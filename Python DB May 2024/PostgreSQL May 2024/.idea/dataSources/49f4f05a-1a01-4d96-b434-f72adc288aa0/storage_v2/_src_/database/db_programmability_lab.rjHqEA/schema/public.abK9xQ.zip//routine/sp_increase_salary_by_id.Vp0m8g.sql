create procedure sp_increase_salary_by_id(IN id integer)
    language plpgsql
as
$$
BEGIN
    UPDATE employees
    SET salary = salary * 1.05
    WHERE employee_id = id;
END;
$$;

alter procedure sp_increase_salary_by_id(integer) owner to postgres;

