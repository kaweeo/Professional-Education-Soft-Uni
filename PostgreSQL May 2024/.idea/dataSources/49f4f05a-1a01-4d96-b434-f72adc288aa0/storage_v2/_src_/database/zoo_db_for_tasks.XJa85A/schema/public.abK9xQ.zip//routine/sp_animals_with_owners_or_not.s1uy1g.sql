create function sp_animals_with_owners_or_not(animal_name character varying)
    returns TABLE(output character varying)
    language plpgsql
as
$$
        BEGIN
            SELECT
                o.name
            FROM animals a
                JOIN owners o on a.owner_id = o.id
            WHERE a.name = animal_name;
        end;
    $$;

alter function sp_animals_with_owners_or_not(varchar) owner to postgres;

