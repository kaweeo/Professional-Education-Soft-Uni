create function fn_creator_with_board_games(first_name_creator character varying, OUT total_number_creators integer) returns integer
    language plpgsql
as
$$
BEGIN
    SELECT COUNT(board_game_id)
    INTO total_number_creators
    FROM creators
             JOIN public.creators_board_games cbg on creators.id = cbg.creator_id
    WHERE creators.first_name = first_name_creator
    GROUP BY creators.first_name;

    IF total_number_creators IS NULL THEN
        total_number_creators := 0;
    END IF;

END;

$$;

alter function fn_creator_with_board_games(varchar, out integer) owner to postgres;

