create function fn_is_word_comprised(set_of_letters character varying, word character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    idx    INT;
    letter VARCHAR;
BEGIN
    FOR idx IN 1..length(word)
        LOOP
            letter := substring(lower(word), idx, 1);
            IF position(letter IN lower(set_of_letters)) = 0 THEN
                RETURN FALSE;
            END IF;
        END LOOP;

    RETURN TRUE;
END;
$$;

alter function fn_is_word_comprised(varchar, varchar) owner to postgres;

