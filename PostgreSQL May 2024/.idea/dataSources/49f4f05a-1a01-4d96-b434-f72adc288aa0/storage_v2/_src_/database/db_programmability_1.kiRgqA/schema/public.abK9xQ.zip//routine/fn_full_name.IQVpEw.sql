create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
        BEGIN
            IF first_name IS NULL AND last_name IS NULL THEN
                RETURN NULL;
            ELSEIF first_name IS NULL THEN
                RETURN INITCAP(last_name);
            ELSEIF last_name IS NULL THEN
                RETURN INITCAP(first_name);
            ELSE
                RETURN INITCAP(first_name) || ' ' || INITCAP(last_name);
            END IF;
        END
    $$;

alter function fn_full_name(varchar, varchar, out varchar) owner to postgres;

