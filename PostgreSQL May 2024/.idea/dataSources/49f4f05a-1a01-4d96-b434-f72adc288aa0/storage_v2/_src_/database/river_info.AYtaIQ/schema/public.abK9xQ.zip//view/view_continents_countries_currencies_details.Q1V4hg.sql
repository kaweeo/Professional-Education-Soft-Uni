create view view_continents_countries_currencies_details(continent_details, country_information, currencies) as
SELECT concat(continents.continent_name, ': ', continents.continent_code)                                AS continent_details,
       concat_ws(' - '::text, countries.country_name, countries.capital, countries.area_in_sq_km,
                 'km2')                                                                                  AS country_information,
       concat(currencies.description, ' (', currencies.currency_code, ')')                               AS currencies
FROM continents,
     countries,
     currencies
WHERE continents.continent_code = countries.continent_code
  AND currencies.currency_code = countries.currency_code
ORDER BY (concat_ws(' - '::text, countries.country_name, countries.capital, countries.area_in_sq_km, 'km2')),
         (concat(currencies.description, ' (', currencies.currency_code, ')'));

alter table view_continents_countries_currencies_details
    owner to postgres;

