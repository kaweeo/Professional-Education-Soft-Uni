create view view_river_info("River Information") as
SELECT concat('The river', ' ', rivers.river_name, ' ', 'flows into the', ' ', rivers.outflow, ' ', 'and is', ' ',
              rivers.length, ' ', 'kilometers long.') AS "River Information"
FROM rivers
ORDER BY rivers.river_name;

alter table view_river_info
    owner to postgres;

