create procedure sp_deposit_money(IN account_id integer, IN money_amount numeric)
    language plpgsql
as
$$
BEGIN
    IF (SELECT balance FROM accounts WHERE id = account_id) IS NULL THEN
        RETURN;
    ELSE
        UPDATE
            accounts
        SET
            balance = balance + money_amount
        WHERE
            id = account_id;
    END IF;
    COMMIT;
END
$$;

alter procedure sp_deposit_money(integer, numeric) owner to postgres;

