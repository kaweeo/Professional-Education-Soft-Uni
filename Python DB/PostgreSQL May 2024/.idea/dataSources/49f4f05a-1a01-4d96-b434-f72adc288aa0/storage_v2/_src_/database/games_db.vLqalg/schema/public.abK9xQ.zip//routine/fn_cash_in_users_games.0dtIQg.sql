create function fn_cash_in_users_games(game_name character varying)
    returns TABLE(total_cash numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT ROUND(SUM(cash):: numeric, 2) AS total_cash
        FROM (SELECT cash,
                     ROW_NUMBER() OVER (ORDER BY users_games.cash DESC) AS row_num
              FROM users_games
                JOIN games ON users_games.game_id = games.id
              WHERE games.name = game_name) AS subquery
        WHERE row_num % 2 = 1;
end;
$$;

alter function fn_cash_in_users_games(varchar) owner to postgres;

