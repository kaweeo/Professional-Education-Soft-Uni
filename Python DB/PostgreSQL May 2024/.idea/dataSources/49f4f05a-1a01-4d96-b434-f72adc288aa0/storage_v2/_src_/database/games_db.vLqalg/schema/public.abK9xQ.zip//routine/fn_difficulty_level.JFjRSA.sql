create function fn_difficulty_level(level integer, OUT difficulty_level character varying) returns character varying
    language plpgsql
as
$$
BEGIN
    IF level <= 40 THEN
        difficulty_level := 'Normal Difficulty';
    ELSEIF level between 41 AND 60 THEN
        difficulty_level := 'Nightmare Difficulty';
    ELSE
        difficulty_level := 'Hell Difficulty';
    END IF;
END;
$$;

alter function fn_difficulty_level(integer, out varchar) owner to postgres;

