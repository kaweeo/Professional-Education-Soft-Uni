create function fn_is_game_over(is_game_over boolean)
    returns TABLE(name character varying, game_type_id integer, is_finished boolean)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT g.name,
               g.game_type_id,
               g.is_finished
        FROM games g
        WHERE g.is_finished = is_game_over;
END;
$$;

alter function fn_is_game_over(boolean) owner to postgres;

