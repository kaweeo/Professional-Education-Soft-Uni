create view continent_currency_usage(continent_code, currency_code, currency_usage) as
SELECT c.continent_code,
       c.currency_code,
       count(*) AS currency_usage
FROM countries c
GROUP BY c.continent_code, c.currency_code
HAVING count(*) > 1
   AND count(*) = ((SELECT count(*) AS most_used_curr
                    FROM countries c2
                    WHERE c2.continent_code = c.continent_code
                    GROUP BY c2.currency_code
                    ORDER BY (count(*)) DESC
                    LIMIT 1))
ORDER BY (count(*)) DESC, c.continent_code;

alter table continent_currency_usage
    owner to postgres;

