create view view_company_chart("Full Name", "Job Title") as
SELECT company_chart.full_name AS "Full Name",
       company_chart.job_title AS "Job Title"
FROM company_chart
WHERE company_chart.manager_id = 184;

alter table view_company_chart
    owner to postgres;

