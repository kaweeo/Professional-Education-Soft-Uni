create view view_initials(initial, last_name) as
SELECT "left"(employees.first_name::text, 2) AS initial,
       employees.last_name
FROM employees
ORDER BY employees.last_name;

alter table view_initials
    owner to postgres;

