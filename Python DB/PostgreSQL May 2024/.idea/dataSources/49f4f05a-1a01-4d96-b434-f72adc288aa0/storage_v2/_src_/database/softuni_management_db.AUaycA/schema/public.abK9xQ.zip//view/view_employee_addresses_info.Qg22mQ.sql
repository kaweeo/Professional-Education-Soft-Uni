create view view_employee_addresses_info(full_name, department_id, address) as
SELECT concat(employees.first_name, ' ', employees.last_name) AS full_name,
       employees.department_id,
       concat(addresses.number, ' ', addresses.street)        AS address
FROM employees,
     addresses
WHERE employees.address_id = addresses.id;

alter table view_employee_addresses_info
    owner to postgres;

