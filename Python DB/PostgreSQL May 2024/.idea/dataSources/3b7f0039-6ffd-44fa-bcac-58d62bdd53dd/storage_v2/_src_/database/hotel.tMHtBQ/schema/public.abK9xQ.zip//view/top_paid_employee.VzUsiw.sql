create view top_paid_employee(id, first_name, last_name, job_title, department_id, salary) as
SELECT id,
       first_name,
       last_name,
       job_title,
       department_id,
       salary
FROM employees
ORDER BY salary DESC
LIMIT 1;

alter table top_paid_employee
    owner to postgres;

