# from project.equipment.base_equipment import BaseEquipment
#
#
# class KneePad(BaseEquipment):
#     PROTECTION = 120
#     PRICE = 15
#
#     def __init__(self):
#         super().__init__(self.PROTECTION, self.PRICE)
#
#     def increase_price(self):
#         self.PRICE *= 1.2


from project.equipment.base_equipment import BaseEquipment


class KneePad(BaseEquipment):
    PERCENTAGE_PRICE_INCREASE = 1.2

    def __init__(self):
        super().__init__(120, 15)

    def increase_price(self):
        self.price *= self.PERCENTAGE_PRICE_INCREASE